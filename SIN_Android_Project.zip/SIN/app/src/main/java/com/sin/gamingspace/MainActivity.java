package com.sin.gamingspace;

import android.app.*;import android.os.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import android.content.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
  LinearLayout root, games; int red=Color.rgb(255,45,72);
  int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
  TextView tv(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(dp(16),0,dp(16),0);return t;}
  GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
  public void onCreate(Bundle b){super.onCreate(b); build();}
  void build(){
    root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(18),dp(18),dp(12));root.setBackgroundColor(Color.rgb(8,8,10));setContentView(root);
    LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);TextView logo=tv("SIN",34,Color.WHITE);logo.setTypeface(null,1);head.addView(logo,new LinearLayout.LayoutParams(0,dp(60),1));TextView gear=tv("⚙",26,Color.LTGRAY);head.addView(gear,new LinearLayout.LayoutParams(dp(50),dp(60)));root.addView(head);
    TextView sub=tv("GAMING SPACE",12,red);sub.setTypeface(null,1);root.addView(sub,new LinearLayout.LayoutParams(-1,dp(24)));
    TextView boost=tv("⚡  BOOST NOW",18,Color.WHITE);boost.setGravity(Gravity.CENTER);boost.setTypeface(null,1);boost.setBackground(bg(Color.rgb(190,25,48),20));root.addView(boost,new LinearLayout.LayoutParams(-1,dp(58)));
    LinearLayout stats=new LinearLayout(this);stats.setPadding(0,dp(14),0,dp(14));String[] a={"FPS\n60","RAM\n42%","CPU\n18%"};for(String s:a){TextView x=tv(s,15,Color.WHITE);x.setGravity(Gravity.CENTER);x.setBackground(bg(Color.rgb(20,20,24),18));stats.addView(x,new LinearLayout.LayoutParams(0,dp(72),1)); if(!s.equals(a[2])) ((LinearLayout.LayoutParams)x.getLayoutParams()).setMargins(0,0,dp(8),0);}root.addView(stats);
    TextView title=tv("YOUR GAMES",20,Color.WHITE);title.setTypeface(null,1);root.addView(title,new LinearLayout.LayoutParams(-1,dp(48)));
    games=new LinearLayout(this);games.setOrientation(LinearLayout.VERTICAL);root.addView(games,new LinearLayout.LayoutParams(-1,0,1)); addGame("🎮  Free Fire","Ready to launch");addGame("🎯  Mobile Legends","Ready to launch");addGame("⚔  PUBG Mobile","Ready to launch");
    LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);String[] ns={"⌂\nHome","⚡\nBoost","✚\nTools","⚙\nSettings"};for(String n:ns){TextView x=tv(n,12,Color.LTGRAY);x.setGravity(Gravity.CENTER);nav.addView(x,new LinearLayout.LayoutParams(0,dp(62),1));}root.addView(nav);
  }
  void addGame(String name,String status){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),0,dp(8),0);row.setBackground(bg(Color.rgb(18,18,22),18));TextView n=tv(name+"\n"+status,15,Color.WHITE);row.addView(n,new LinearLayout.LayoutParams(0,dp(68),1));TextView go=tv("PLAY",12,Color.WHITE);go.setGravity(Gravity.CENTER);go.setBackground(bg(Color.rgb(120,20,35),14));row.addView(go,new LinearLayout.LayoutParams(dp(72),dp(40)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(68));p.setMargins(0,0,0,dp(10));games.addView(row,p);}
}
